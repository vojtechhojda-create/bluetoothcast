# BluetoothCast

Přehrávej zvuk z PC na libovolném Bluetooth zařízení přes telefon s Androidem. V počítači nepotřebuješ žádný Bluetooth adaptér.

[English](README.md)

## Proč to vzniklo

Můj stolní počítač nemá Bluetooth a nechtěl jsem kupovat dongle jen kvůli sluchátkům. Telefon Bluetooth umí, takže BluetoothCast z něj dělá most: PC zachytí, co zrovna hraje, pošle to přes Wi-Fi a telefon to přehraje do sluchátek, reproduktoru, autorádia nebo čehokoliv jiného, s čím je spárovaný.

## Jak to funguje

```
┌─────────────┐   Wi-Fi (raw PCM)   ┌──────────────┐   Bluetooth   ┌───────────────┐
│ Windows PC  │ ──────────────────► │ Android      │ ────────────► │ Sluchátka,    │
│ (odesílač)  │ ◄──── souhlas ───── │ (na pozadí)  │               │ reproduktor…  │
└─────────────┘                     └──────────────┘               └───────────────┘
```

1. Malá služba v telefonu poslouchá na portu 8766 a odpovídá na vyhledávací broadcast.
2. Skript na PC telefon najde, připojí se a požádá o povolení.
3. Telefon zobrazí v notifikaci **Povolit** / **Zamítnout** (nebo povolí sám, pokud máš nastavený PIN).
4. PC posílá nekomprimovaný zvuk v blocích po 20 ms a telefon ho přehrává přes nízkolatenční `AudioTrack`. Když se síť zadrhne a nahromadí se zvuk, telefon nejstarší data zahodí a dožene aktuální stav, takže se zpoždění nezvětšuje.

## Funkce

**Telefon**
- Běží jako služba na pozadí s notifikací, ne jako plná aplikace, kterou bys musel mít otevřenou.
- Dlaždice v rychlých nastaveních vedle Wi-Fi a Bluetooth. Ukazuje *Vypnuto*, *Čeká na PC* nebo *Připojeno k MOJE-PC*.
- Notifikace s běžícím časovačem a tlačítky **Odpojit** a **Vypnout**.
- Souhlas při každém připojení, nebo volitelně automatické povolení pro PC, které pošle tvůj PIN.
- Hlavní obrazovka se živým stavem, adresou telefonu, PINem a zkratkami do nastavení notifikací a baterie.

**PC**
- Výběr zdroje zvuku, který se zachytává, a živý stavový řádek (čas, rychlost, zahozené bloky).
- Auto-connect a automatické znovupřipojení po výpadku Wi-Fi.
- Telefon najde sám a zapamatuje si jeho adresu.
- Vše se nastavuje v `settings.json`.

## Rychlý start

1. Sestav a nainstaluj APK (viz [Instalace](#instalace)).
2. Spáruj sluchátka nebo reproduktor s telefonem jako obvykle.
3. Otevři BluetoothCast v telefonu a klepni na **Zapnout**.
4. Na PC jednou spusť `BluetoothCast/install.bat` a pak `BluetoothCast/start.bat`.
5. V notifikaci na telefonu klepni na **Povolit**. Zvuk z PC teď hraje v Bluetooth zařízení.

## Požadavky

- Windows 10 nebo 11 s Pythonem 3.9+ (funguje i s 3.13)
- Android 8.0 (API 26) nebo novější
- PC a telefon ve stejné Wi-Fi síti

## Instalace

### Android aplikace

Android Studio nepotřebuješ. Repozitář obsahuje workflow pro GitHub Actions, které APK sestaví za tebe.

1. Forkni repozitář, nebo ho nahraj na vlastní účet.
2. Otevři záložku **Actions** a spusť **Build APK** (spouští se i po každém pushi).
3. Po dokončení stáhni artefakt `pcaudio-apk` a rozbal ho, uvnitř je `app-debug.apk`.
4. Nainstaluj APK do telefonu, buď zkopírováním přes USB a otevřením ve správci souborů, nebo příkazem `adb install -r app-debug.apk`. Android se zeptá na povolení instalace z neznámých zdrojů.
5. Otevři aplikaci a povol notifikace.

> APK se při každém buildu na GitHubu podepisuje jiným ladicím klíčem, takže starou verzi před instalací nové odinstaluj.

Chceš-li to sestavit lokálně, potřebuješ JDK 17 a Android SDK: `gradle assembleDebug` (výstup v `app/build/outputs/apk/debug/`).

### PC odesílač

```
pip install pyaudiowpatch numpy
python pc_audio_sender.py
```

`install.bat` a `start.bat` dělají totéž bez psaní. Při prvním spuštění se vedle skriptu vytvoří `settings.json`.

## Používání aplikace

**Hlavní obrazovka.** Jedno velké tlačítko zapíná a vypíná službu. Karta nad ním ukazuje aktuální stav a v době čekání adresu, ke které se PC připojí.

**Dlaždice v rychlých nastaveních.** V aplikaci klepni na *Přidat do rychlých nastavení* (Android 13+), nebo otevři úpravu rychlých nastavení a přetáhni nahoru dlaždici **BluetoothCast**. Klepnutím službu zapneš nebo vypneš, dlouhým podržením otevřeš aplikaci.

**Notifikace.** Dokud služba běží, je vidět trvalá notifikace. Když je připojený PC, ukazuje jeho název a jak dlouho se přehrává. *Odpojit* ukončí jen aktuální spojení, *Vypnout* zastaví celou službu.

## PC odesílač

### settings.json

| Klíč | Význam |
|---|---|
| `phone_ip` | Adresa telefonu. Prázdné = hledat automaticky. Po prvním úspěšném připojení se vyplní samo. |
| `pin` | PIN z aplikace pro automatické povolení (text v uvozovkách, např. `"123456"`). |
| `discovery` | Když uložená adresa nefunguje, zkusit telefon najít v síti. |
| `device` | Zdroj zvuku, který se zachytává (stačí část názvu). Prázdné = výchozí výstup. |
| `auto_connect` | `true`: na nic se neptat a zkoušet, dokud telefon neodpoví. `false`: zeptat se na zařízení a při nenalezení telefonu skončit. |
| `reconnect` | Po vypadnutí spojení se znovu připojit. |
| `retry_delay_s`, `max_retries` | Pauza mezi pokusy a jejich počet (`0` = bez omezení). |
| `on_denied` | `"exit"` nebo `"retry"` po zamítnutí žádosti na telefonu. |
| `remember_choices` | Ukládat nalezenou adresu telefonu a vybrané zařízení zpět do souboru. |
| `chunk_ms`, `queue_size` | Velikost bloku zvuku a kolik bloků se může nahromadit, než se začnou zahazovat. |

Když je v souboru syntaktická chyba, skript to napíše, použije výchozí hodnoty a soubor nepřepíše.

### Příkazová řádka

| Přepínač | Význam |
|---|---|
| `--ip 10.0.0.4` | Adresa telefonu jen pro tento běh |
| `--pin 123456` | PIN jen pro tento běh |
| `--device 2` | Vybere zdroj číslo 2 (viz `--list`) |
| `--list` | Vypíše dostupné zdroje a skončí |
| `--config cesta` | Použije jiný soubor s nastavením |

## Povolení bez klepání pomocí PINu

Telefon se normálně ptá na souhlas při každém připojení. Když se připojuješ často, můžeš jedno důvěryhodné PC pouštět bez ptaní:

1. V aplikaci zapni **Povolit automaticky s PINem** a poznamenej si PIN (nebo ho zkopíruj).
2. Na PC ho zapiš do `settings.json` jako `"pin": "123456"`, nebo použij `--pin`.
3. Od teď se toto PC povolí bez dotazu. PC se špatným nebo chybějícím PINem dostane normální dotaz.

Nový PIN můžeš v aplikaci kdykoliv vygenerovat, čímž starý přestane platit. Omezení najdeš v části [Bezpečnost](#bezpečnost).

## Řešení problémů

| Problém | Co zkusit |
|---|---|
| Telefon se nenajde | Některé routery izolují klienty nebo blokují broadcast. Zapiš adresu telefonu do `phone_ip` nebo použij `--ip`. |
| Spojení vyprší | Zkontroluj, že jsou obě zařízení ve stejné síti (`ipconfig` na PC, adresu telefonu ukazuje aplikace), že neběží VPN a že router nemá zapnutou izolaci klientů. |
| Nepřišla notifikace | Povol aplikaci notifikace. Na hlavní obrazovce se při vypnutých zobrazí upozornění. |
| Služba se po čase zastaví | Vypni pro aplikaci optimalizaci baterie (tlačítko na hlavní obrazovce). Někteří výrobci služby na pozadí agresivně ukončují. |
| Praskání nebo výpadky | Zvyš `queue_size`, přibliž se k routeru nebo připoj PC kabelem. |
| Zvuk zaostává za obrazem | Počítej se zpožděním zhruba 100–200 ms celkem (je to odhad, závisí na Wi-Fi a Bluetooth zařízení). Pro hudbu a většinu her v pořádku, u videa to může být znát. |
| „Aplikace nebyla nainstalována“ | Je nainstalovaná předchozí verze podepsaná jiným klíčem. Nejdřív ji odinstaluj. |
| Chybí dlaždice | Přidej ji v úpravě rychlých nastavení. Na některých telefonech je třeba aplikaci nejdřív jednou otevřít. |
| `pyaudiowpatch` se nenainstaluje | Zkus jinou verzi Pythonu (3.11 nebo 3.12). |
| Dotaz firewallu ve Windows | Povol přístup v soukromých sítích. |
| Zvuk hraje i z reproduktorů PC | Ztlum je, nebo přepni výstup PC na tiché zařízení. |

## Časté dotazy

**Funguje to s iPhonem?** Ne, přijímač je aplikace pro Android.

**Potřebuje to internet?** Ne. Všechno zůstává v lokální síti.

**Může streamovat víc PC najednou?** Ne, vždy jen jedno.

**Mění to hlasitost?** Hlasitost řídí telefon a Bluetooth zařízení. Hlasitost PC se na zachycený zvuk u většiny nastavení neprojeví.

## Protokol

Port `8766`, UDP i TCP.

- **Discovery (UDP):** PC pošle broadcast `CMF_AUDIO?` a telefon odpoví `CMF_AUDIO!`.
- **Handshake (TCP):** PC pošle jeden řádek JSON zakončený `\n`, např. `{"name": "muj-pc", "rate": 48000, "channels": 2, "pin": "123456"}`. Položka `pin` je volitelná.
- **Souhlas:** telefon odpoví `OK\n` nebo `NO\n`. Pokud se zobrazí dotaz, po 20 sekundách vyprší.
- **Stream:** po `OK` PC posílá surové 16bitové PCM (little-endian, prokládané kanály).

## Bezpečnost

Port je otevřený v lokální síti, takže kdokoliv ve stejné Wi-Fi může poslat žádost. Bez tvého souhlasu se nic nepřehraje, pokud odesílatel nezná PIN a automatické povolení není zapnuté. Samotné spojení není šifrované a PIN putuje jako prostý text, takže ho může přečíst každý, kdo vidí provoz ve tvé síti. Automatické povolení používej jen v síti, které věříš, a nepoužívej to ve veřejné Wi-Fi.

## Omezení

- Odesílač funguje jen na Windows (využívá WASAPI loopback).
- Zvuk je nekomprimovaný, což drží nízké zpoždění, ale chce to rozumně stabilní Wi-Fi (zhruba 1,5 Mbit/s).
- APK z workflow je ladicí (debug) sestavení.

## Plány

- Šifrované spojení
- Komprese Opus pro slabší sítě
- Ikona v tray a výběr výstupního zařízení na PC
- Nastavitelná velikost bufferu v aplikaci

## Seznam změn

**1.1**
- Nová hlavní obrazovka se živým stavem, PINem a zkratkami
- Dlaždice v rychlých nastaveních
- Nová ikona a bohatší notifikace s časovačem a tlačítkem Odpojit
- Volitelné automatické povolení pomocí PINu
- PC odesílač: výběr zdroje, živý stavový řádek, auto-connect a znovupřipojení, `settings.json`

**1.0**
- První verze

## Licence

MIT. Viz [LICENSE](BluetoothCast/LICENSE).
