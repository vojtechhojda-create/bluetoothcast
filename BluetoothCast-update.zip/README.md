# BluetoothCast

Play your PC's audio on any Bluetooth device through your Android phone. No Bluetooth adapter needed in the PC.

[Česky](README.cs.md)

## Why this exists

My desktop has no Bluetooth, and I didn't want to buy a dongle just to use a pair of earbuds. Phones already speak Bluetooth, so BluetoothCast uses the phone as the bridge: the PC captures what is playing, sends it over Wi-Fi, and the phone plays it out to headphones, a speaker, a car stereo or anything else it is paired with.

## How it works

```
┌─────────────┐   Wi-Fi (raw PCM)   ┌──────────────┐   Bluetooth   ┌───────────────┐
│ Windows PC  │ ──────────────────► │ Android      │ ────────────► │ Headphones,   │
│ (sender)    │ ◄──── approval ──── │ (background) │               │ speaker, ...  │
└─────────────┘                     └──────────────┘               └───────────────┘
```

1. A small service on the phone listens on port 8766 and answers discovery broadcasts.
2. The PC script finds the phone, connects and asks for permission.
3. The phone shows **Allow** / **Deny** in a notification (or approves automatically if you set up a PIN).
4. The PC streams uncompressed audio in 20 ms blocks and the phone plays it through a low-latency `AudioTrack`. If the network stalls and audio piles up, the phone drops the oldest data and catches up instead of letting the delay grow.

## Features

**Phone**
- Runs as a background service with a notification, not as a full app you have to keep open.
- Quick Settings tile next to Wi-Fi and Bluetooth. It shows *Off*, *Waiting for PC* or *Connected to MY-PC*.
- Notification with a running timer and **Disconnect** / **Turn off** buttons.
- Consent on every connection, or optional automatic approval for a PC that sends your PIN.
- Main screen with live status, the phone's address, PIN, and shortcuts for notification and battery settings.

**PC**
- Choose which output to capture, with a live status line (time, bitrate, dropped blocks).
- Auto-connect and automatic reconnect after a Wi-Fi hiccup.
- Finds the phone by itself and remembers its address.
- Everything configurable in `settings.json`.

## Quick start

1. Build and install the APK (see [Installation](#installation)).
2. Pair your headphones or speaker with the phone as usual.
3. Open BluetoothCast on the phone and tap **Turn on**.
4. On the PC, run `BluetoothCast/install.bat` once, then `BluetoothCast/start.bat`.
5. Tap **Allow** in the notification on the phone. The audio from your PC now plays on the Bluetooth device.

## Requirements

- Windows 10 or 11 with Python 3.9+ (works with 3.13)
- Android 8.0 (API 26) or newer
- PC and phone on the same Wi-Fi network

## Installation

### Android app

You don't need Android Studio. The repository includes a GitHub Actions workflow that builds the APK.

1. Fork this repository or push it to your own account.
2. Open the **Actions** tab and run **Build APK** (it also runs on every push).
3. When it finishes, download the `pcaudio-apk` artifact and unzip it to get `app-debug.apk`.
4. Install the APK on your phone, either by copying it over USB and opening it in a file manager, or with `adb install -r app-debug.apk`. Android will ask you to allow installs from unknown sources.
5. Open the app and allow notifications.

> The APK is signed with a different debug key on every GitHub build, so uninstall the old version before installing a new one.

To build locally instead you need JDK 17 and the Android SDK: `gradle assembleDebug` (output in `app/build/outputs/apk/debug/`).

### PC sender

```
pip install pyaudiowpatch numpy
python pc_audio_sender.py
```

`install.bat` and `start.bat` do the same without typing. On first run a `settings.json` is created next to the script.

## Using the app

**Main screen.** One big button turns the service on or off. The card above it shows the current state and, while waiting, the address the PC will connect to.

**Quick Settings tile.** Tap *Add to Quick Settings* in the app (Android 13+), or open the Quick Settings editor yourself and drag the **BluetoothCast** tile up. Tap it to turn the service on or off, long-press to open the app.

**Notification.** While the service runs there is a persistent notification. When a PC is connected it shows its name and how long it has been playing. *Disconnect* ends only the current connection, *Turn off* stops the whole service.

## PC sender

### settings.json

| Key | Meaning |
|---|---|
| `phone_ip` | Phone address. Empty means discover automatically. It is filled in after the first successful connection. |
| `pin` | PIN from the app, for automatic approval (a string, e.g. `"123456"`). |
| `discovery` | If the saved address doesn't work, try to find the phone on the network. |
| `device` | Audio source to capture (part of the name is enough). Empty means the default output. |
| `auto_connect` | `true`: never ask questions and keep trying until the phone answers. `false`: ask which device to use and give up if the phone isn't found. |
| `reconnect` | Reconnect automatically after the connection drops. |
| `retry_delay_s`, `max_retries` | Pause between attempts and how many to make (`0` = unlimited). |
| `on_denied` | `"exit"` or `"retry"` after the request is denied on the phone. |
| `remember_choices` | Save the found phone address and chosen device back to the file. |
| `chunk_ms`, `queue_size` | Audio block size and how many blocks may queue up before old ones are dropped. |

If the file contains a syntax error, the script says so, uses the defaults and leaves the file untouched.

### Command line

| Option | Meaning |
|---|---|
| `--ip 10.0.0.4` | Phone address for this run only |
| `--pin 123456` | PIN for this run only |
| `--device 2` | Pick source number 2 (see `--list`) |
| `--list` | Print the available sources and exit |
| `--config path` | Use another settings file |

## Skipping the prompt with a PIN

By default the phone asks for permission on every connection. If you reconnect often, you can let one trusted PC in without asking:

1. In the app, turn on **Allow automatically with PIN** and note the PIN (or copy it).
2. On the PC, put it into `settings.json` as `"pin": "123456"`, or use `--pin`.
3. From now on this PC is approved without a prompt. A PC with a wrong or missing PIN still gets the normal prompt.

You can generate a new PIN in the app at any time, which locks the old one out. See [Security](#security) for the limits of this.

## Troubleshooting

| Problem | What to try |
|---|---|
| Phone is not found | Some routers isolate clients or block broadcasts. Put the phone's address into `phone_ip` or use `--ip`. |
| Connection times out | Check that both devices are on the same network (`ipconfig` on the PC, the app shows the phone's address), that no VPN is running, and that client isolation is off on the router. |
| No notification appears | Allow notifications for the app. The main screen shows a warning when they are off. |
| Service stops after a while | Turn off battery optimization for the app (button on the main screen). Some vendors kill background services aggressively. |
| Crackling or dropouts | Increase `queue_size`, move closer to the router, or connect the PC with a cable. |
| Audio lags behind video | Expect roughly 100–200 ms in total (an estimate, it depends on your Wi-Fi and Bluetooth device). Fine for music and most games, noticeable in video. |
| "App not installed" | A previous version signed with a different key is still installed. Uninstall it first. |
| Tile is missing | Add it in the Quick Settings editor. On some phones you need to open the app once first. |
| `pyaudiowpatch` won't install | Try a different Python version (3.11 or 3.12). |
| Windows firewall prompt | Allow access on private networks. |
| Sound also plays on the PC speakers | Mute them, or switch the PC output to a silent device. |

## FAQ

**Does it work with an iPhone?** No, the receiver is an Android app.

**Does it need internet?** No. Everything stays on your local network.

**Can several PCs stream at once?** No, one at a time.

**Does it change the volume?** Volume is controlled by the phone and the Bluetooth device. The PC's own volume slider does not affect what is captured on most setups.

## Protocol

Port `8766`, both UDP and TCP.

- **Discovery (UDP):** the PC broadcasts `CMF_AUDIO?` and the phone replies `CMF_AUDIO!`.
- **Handshake (TCP):** the PC sends one JSON line terminated by `\n`, for example `{"name": "my-pc", "rate": 48000, "channels": 2, "pin": "123456"}`. `pin` is optional.
- **Consent:** the phone answers `OK\n` or `NO\n`. If a prompt is shown, it times out after 20 seconds.
- **Stream:** after `OK`, the PC sends raw 16-bit little-endian interleaved PCM.

## Security

The port is open on your local network, so anyone on the same Wi-Fi can send a request. Nothing is played without your approval, unless the sender knows the PIN and automatic approval is on. The connection itself is not encrypted, and the PIN travels in plain text, so anyone who can observe your network traffic could read it. Use automatic approval only on a network you trust, and don't run this on public Wi-Fi.

## Limitations

- The sender is Windows-only (it relies on WASAPI loopback capture).
- Audio is uncompressed, which keeps latency low but needs a reasonably stable Wi-Fi connection (about 1.5 Mbit/s).
- The APK from the workflow is a debug build.

## Roadmap

- Encrypted connection
- Opus compression for weaker networks
- Tray icon and output device selection on the PC
- Adjustable buffer size in the app

## Changelog

**1.1**
- New main screen with live status, PIN and shortcuts
- Quick Settings tile
- New icon and a richer notification with a timer and a Disconnect button
- Optional automatic approval with a PIN
- PC sender: source selection, live status line, auto-connect and reconnect, `settings.json`

**1.0**
- First version

## License

MIT. See [LICENSE](BluetoothCast/LICENSE).
